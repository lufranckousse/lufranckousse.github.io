package com.example.modulethreeassignment.analytics;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import com.example.modulethreeassignment.WeightEntry;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;

public class WeightAnalyticsTest {
    private List<WeightEntry> sample() {
        return Arrays.asList(
                new WeightEntry(3, "09/20/2026", 226.0),
                new WeightEntry(1, "09/01/2026", 240.0),
                new WeightEntry(2, "09/10/2026", 233.0));
    }

    @Test
    public void sortChronologically_ordersByDateNotDatabaseId() {
        List<WeightEntry> sorted = WeightAnalytics.sortChronologically(sample(), false);
        assertEquals("09/01/2026", sorted.get(0).getDate());
        assertEquals("09/20/2026", sorted.get(2).getDate());
    }

    @Test
    public void sortChronologically_canReturnNewestFirst() {
        List<WeightEntry> sorted = WeightAnalytics.sortChronologically(sample(), true);
        assertEquals("09/20/2026", sorted.get(0).getDate());
    }

    @Test
    public void filterByDateRange_isInclusive() {
        List<WeightEntry> filtered = WeightAnalytics.filterByDateRange(sample(), "09/10/2026", "09/20/2026");
        assertEquals(2, filtered.size());
        assertEquals("09/10/2026", filtered.get(0).getDate());
    }

    @Test(expected = IllegalArgumentException.class)
    public void filterByDateRange_rejectsReversedRange() {
        WeightAnalytics.filterByDateRange(sample(), "09/20/2026", "09/01/2026");
    }

    @Test
    public void calculateProgress_usesChronologicalEndpoints() {
        WeightAnalytics.ProgressSummary summary = WeightAnalytics.calculateProgress(sample(), 220.0);
        assertFalse(summary.isEmpty());
        assertEquals(240.0, summary.getStartingWeight(), 0.001);
        assertEquals(226.0, summary.getCurrentWeight(), 0.001);
        assertEquals(-14.0, summary.getNetChange(), 0.001);
        assertEquals(6.0, summary.getPoundsRemaining(), 0.001);
        assertEquals(70.0, summary.getPercentTowardGoal(), 0.001);
    }

    @Test
    public void determineTrend_detectsDecreasingHistory() {
        assertEquals(WeightAnalytics.Trend.DECREASING, WeightAnalytics.determineTrend(sample()));
    }

    @Test
    public void determineTrend_detectsStableHistory() {
        List<WeightEntry> stable = Arrays.asList(
                new WeightEntry(1, "09/01/2026", 200.00),
                new WeightEntry(2, "09/02/2026", 200.05),
                new WeightEntry(3, "09/03/2026", 200.00));
        assertEquals(WeightAnalytics.Trend.STABLE, WeightAnalytics.determineTrend(stable));
    }
}

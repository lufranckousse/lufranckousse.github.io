CS 360 Project Three - WeightTrack
Student: Lufranc Kousse Akodjo

Project purpose
---------------
WeightTrack is a functional Android weight-tracking application built from the Project Two UI. It supports account creation/login, persistent SQLite weight data, CRUD operations, goal weight tracking, and optional SMS notifications when a goal is reached.

Main project requirements implemented
-------------------------------------
1. Login/account creation
   - Existing users are validated against SQLite.
   - New users can create a username/password account.
   - Password values are hashed before storage.

2. SQLite database
   - users table: login data, phone number, SMS preference.
   - weights table: date and daily weight records.
   - goals table: persistent goal weight for each user.
   - Create: Add Weight Entry.
   - Read: Weight History is rebuilt from SQLite whenever the screen opens/refreshes.
   - Update: Edit button on each weight row and Save Goal button.
   - Delete: Delete button on each weight row with confirmation.

3. SMS notifications
   - SEND_SMS permission is declared in AndroidManifest.xml.
   - Notification Settings lets users save a phone number, grant permission, or choose Not Now.
   - Denying SMS does not stop login, database, or weight tracking functionality.
   - When a saved weight is at or below the user's goal, the app attempts to send an SMS if the user opted in and permission is granted.

4. Coding practices
   - Database logic is separated into DatabaseHelper.
   - WeightEntry is a small model class.
   - Activities use descriptive names and methods.
   - Comments explain non-obvious logic.

Suggested emulator test
-----------------------
1. Run app; LoginActivity should open first.
2. Enter a new username/password and select Create New Account.
3. Add several weight entries and verify they remain after leaving/reopening the screen.
4. Select Edit on one row and change its date or weight.
5. Select Delete on one row and confirm deletion.
6. Change goal weight and verify it remains after restart.
7. Open Notification Settings, save a phone number, and test Allow SMS / Not Now.
8. Confirm the app still works after denying SMS permission.
9. Set a goal higher than or equal to a new weight entry and add that weight to trigger the goal-notification logic.

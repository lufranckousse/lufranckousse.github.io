package com.example.modulethreeassignment;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.modulethreeassignment.data.WeightRepository;
import com.example.modulethreeassignment.validation.InputValidator;

/**
 * Requests SEND_SMS permission and stores the user's notification preference.
 * Denying permission never blocks the rest of the application.
 */
public class SmsPermissionActivity extends Activity {

    private static final int SMS_PERMISSION_REQUEST = 100;

    private long userId;
    private WeightRepository repository;
    private TextView textPermissionStatus;
    private EditText editPhoneNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        userId = getIntent().getLongExtra(LoginActivity.EXTRA_USER_ID, -1);
        if (userId == -1) {
            Toast.makeText(this, "Please log in first.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        repository = new WeightRepository(this);
        textPermissionStatus = findViewById(R.id.textPermissionStatus);
        editPhoneNumber = findViewById(R.id.editPhoneNumber);

        Button buttonSavePhone = findViewById(R.id.buttonSavePhone);
        Button buttonAllowSms = findViewById(R.id.buttonAllowSms);
        Button buttonDenySms = findViewById(R.id.buttonDenySms);
        Button buttonBack = findViewById(R.id.buttonBackToWeights);

        editPhoneNumber.setText(repository.getPhoneNumber(userId));
        updateStatusText();

        buttonSavePhone.setOnClickListener(view -> savePhoneNumber(false));
        buttonAllowSms.setOnClickListener(view -> requestSmsPermission());
        buttonDenySms.setOnClickListener(view -> disableSms());
        buttonBack.setOnClickListener(view -> finish());
    }

    private void requestSmsPermission() {
        if (!savePhoneNumber(true)) {
            return;
        }

        if (checkSelfPermission(Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST
            );
        } else {
            repository.setSmsPreferences(
                    userId,
                    editPhoneNumber.getText().toString(),
                    true
            );
            updateStatusText();
        }
    }

    private boolean savePhoneNumber(boolean requireValue) {
        String phone = editPhoneNumber.getText().toString().trim();
        if (requireValue && phone.isEmpty()) {
            editPhoneNumber.setError("Enter a phone number before enabling SMS");
            editPhoneNumber.requestFocus();
            return false;
        }

        boolean enabled = repository.isSmsEnabled(userId);
        repository.setSmsPreferences(userId, phone, enabled);
        if (!requireValue) {
            Toast.makeText(this, "Phone number saved.", Toast.LENGTH_SHORT).show();
        }
        return true;
    }

    private void disableSms() {
        repository.setSmsPreferences(
                userId,
                editPhoneNumber.getText().toString(),
                false
        );
        textPermissionStatus.setText(
                "SMS notifications are disabled. The rest of the app will continue to work."
        );
    }

    private void updateStatusText() {
        boolean permissionGranted = checkSelfPermission(Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
        boolean enabled = repository.isSmsEnabled(userId);

        if (permissionGranted && enabled) {
            textPermissionStatus.setText(
                    "SMS permission is granted and goal-weight notifications are enabled."
            );
        } else if (permissionGranted) {
            textPermissionStatus.setText(
                    "SMS permission is granted, but notifications are turned off."
            );
        } else {
            textPermissionStatus.setText(
                    "SMS permission has not been granted. The app will still work without SMS."
            );
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode != SMS_PERMISSION_REQUEST) {
            return;
        }

        if (grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            repository.setSmsPreferences(
                    userId,
                    editPhoneNumber.getText().toString(),
                    true
            );
            textPermissionStatus.setText(
                    "SMS notifications have been enabled."
            );
        } else {
            repository.setSmsPreferences(
                    userId,
                    editPhoneNumber.getText().toString(),
                    false
            );
            textPermissionStatus.setText(
                    "Permission was denied. The app will continue without SMS notifications."
            );
        }
    }
}

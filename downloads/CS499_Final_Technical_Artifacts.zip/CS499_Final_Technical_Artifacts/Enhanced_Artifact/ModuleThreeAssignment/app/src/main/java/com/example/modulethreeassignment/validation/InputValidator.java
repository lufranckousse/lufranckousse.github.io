package com.example.modulethreeassignment.validation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Centralizes input rules so Activities do not duplicate validation logic.
 * The class has no Android dependencies, which makes the rules unit testable.
 */
public final class InputValidator {
    public static final int MIN_PASSWORD_LENGTH = 8;
    private static final double MAX_WEIGHT = 1500.0;
    private static final Pattern USERNAME_PATTERN = Pattern.compile("^[A-Za-z0-9._-]{3,30}$");
    private static final Pattern PHONE_PATTERN = Pattern.compile("^\\+?[0-9]{10,15}$");

    private InputValidator() { }

    public static String validateUsername(String username) {
        if (username == null || username.trim().isEmpty()) return "Enter a username";
        if (!USERNAME_PATTERN.matcher(username.trim()).matches()) {
            return "Use 3-30 letters, numbers, periods, underscores, or hyphens";
        }
        return null;
    }

    public static String validatePassword(String password) {
        if (password == null || password.isEmpty()) return "Enter a password";
        if (password.length() < MIN_PASSWORD_LENGTH) {
            return "Password must contain at least " + MIN_PASSWORD_LENGTH + " characters";
        }
        return null;
    }

    public static Double parseWeight(String value) {
        if (value == null || value.trim().isEmpty()) return null;
        try {
            double weight = Double.parseDouble(value.trim());
            return weight > 0 && weight <= MAX_WEIGHT ? weight : null;
        } catch (NumberFormatException exception) {
            return null;
        }
    }

    public static boolean isValidDate(String value) {
        if (value == null || value.trim().isEmpty()) return false;
        SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
        format.setLenient(false);
        try {
            format.parse(value.trim());
            return true;
        } catch (ParseException exception) {
            return false;
        }
    }

    public static boolean isValidPhoneNumber(String value) {
        if (value == null) return false;
        String normalized = value.replace(" ", "").replace("-", "").replace("(", "").replace(")", "");
        return PHONE_PATTERN.matcher(normalized).matches();
    }
}

package com.example.modulethreeassignment;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.modulethreeassignment.data.WeightRepository;
import com.example.modulethreeassignment.validation.InputValidator;

/**
 * Handles account creation and login. User credentials are checked against
 * the persistent SQLite database before the weight-history screen is opened.
 */
public class LoginActivity extends Activity {

    public static final String EXTRA_USER_ID = "user_id";

    private EditText editUsername;
    private EditText editPassword;
    private WeightRepository repository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        repository = new WeightRepository(this);
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);

        Button buttonLogin = findViewById(R.id.buttonLogin);
        Button buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        buttonLogin.setOnClickListener(view -> logIn());
        buttonCreateAccount.setOnClickListener(view -> createAccount());
    }

    private void logIn() {
        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString();

        if (!validateInputs(username, password)) {
            return;
        }

        long userId = repository.authenticate(username, password);
        if (userId == -1) {
            Toast.makeText(this,
                    "Username or password is incorrect.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        openWeightHistory(userId);
    }

    private void createAccount() {
        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString();

        if (!validateInputs(username, password)) {
            return;
        }

        if (repository.usernameExists(username)) {
            Toast.makeText(this,
                    "That username already exists. Please log in or choose another username.",
                    Toast.LENGTH_LONG).show();
            return;
        }

        long userId = repository.createUser(username, password);
        if (userId == -1) {
            Toast.makeText(this,
                    "The account could not be created.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this,
                "Account created successfully.",
                Toast.LENGTH_SHORT).show();
        openWeightHistory(userId);
    }

    private boolean validateInputs(String username, String password) {
        String usernameError = InputValidator.validateUsername(username);
        if (usernameError != null) {
            editUsername.setError(usernameError);
            editUsername.requestFocus();
            return false;
        }

        String passwordError = InputValidator.validatePassword(password);
        if (passwordError != null) {
            editPassword.setError(passwordError);
            editPassword.requestFocus();
            return false;
        }
        return true;
    }

    private void openWeightHistory(long userId) {
        Intent intent = new Intent(this, WeightDataActivity.class);
        intent.putExtra(EXTRA_USER_ID, userId);
        startActivity(intent);
    }
}

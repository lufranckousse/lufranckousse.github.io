package com.example.modulethreeassignment;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import com.example.modulethreeassignment.data.WeightRepository;
import com.example.modulethreeassignment.analytics.WeightAnalytics;
import com.example.modulethreeassignment.validation.InputValidator;

/**
 * Displays weight records from SQLite and implements create, read, update,
 * and delete operations. It also checks whether a new weight reaches the
 * user's goal and sends an SMS alert when permission and settings allow it.
 */
public class WeightDataActivity extends Activity {

    private WeightRepository repository;
    private long userId;
    private EditText editWeight;
    private EditText editDate;
    private EditText editGoalWeight;
    private TextView textGoalWeight;
    private TextView textProgressSummary;
    private EditText editFilterFrom;
    private EditText editFilterTo;
    private TableLayout weightTable;
    private String activeFilterFrom = "";
    private String activeFilterTo = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_data);

        userId = getIntent().getLongExtra(LoginActivity.EXTRA_USER_ID, -1);
        if (userId == -1) {
            Toast.makeText(this, "Please log in first.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        repository = new WeightRepository(this);
        editWeight = findViewById(R.id.editWeight);
        editDate = findViewById(R.id.editDate);
        editGoalWeight = findViewById(R.id.editGoalWeight);
        textGoalWeight = findViewById(R.id.textGoalWeight);
        textProgressSummary = findViewById(R.id.textProgressSummary);
        editFilterFrom = findViewById(R.id.editFilterFrom);
        editFilterTo = findViewById(R.id.editFilterTo);
        weightTable = findViewById(R.id.weightTable);

        Button buttonAddWeight = findViewById(R.id.buttonAddWeight);
        Button buttonSaveGoal = findViewById(R.id.buttonSaveGoal);
        Button buttonApplyFilter = findViewById(R.id.buttonApplyFilter);
        Button buttonClearFilter = findViewById(R.id.buttonClearFilter);
        Button notificationButton = findViewById(R.id.buttonNotificationSettings);
        Button buttonLogout = findViewById(R.id.buttonLogout);

        editDate.setText(new SimpleDateFormat("MM/dd/yyyy", Locale.US).format(new Date()));

        buttonAddWeight.setOnClickListener(view -> addWeight());
        buttonSaveGoal.setOnClickListener(view -> saveGoal());
        buttonApplyFilter.setOnClickListener(view -> applyDateFilter());
        buttonClearFilter.setOnClickListener(view -> clearDateFilter());
        notificationButton.setOnClickListener(view -> openNotificationSettings());
        buttonLogout.setOnClickListener(view -> logOut());

        refreshGoalDisplay();
        refreshWeightTable();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (repository != null) {
            refreshGoalDisplay();
            refreshWeightTable();
        }
    }

    private void addWeight() {
        String weightText = editWeight.getText().toString().trim();
        String date = editDate.getText().toString().trim();

        Double weight = parseWeight(weightText, editWeight);
        if (weight == null) {
            return;
        }

        if (!validateDate(date, editDate)) {
            return;
        }

        long entryId = repository.addWeight(userId, date, weight);
        if (entryId == -1) {
            Toast.makeText(this, "Unable to save the weight entry.", Toast.LENGTH_SHORT).show();
            return;
        }

        editWeight.setText("");
        refreshWeightTable();
        Toast.makeText(this, "Weight entry saved.", Toast.LENGTH_SHORT).show();
        checkGoalAndSendSms(weight);
    }

    private void saveGoal() {
        Double goal = parseWeight(editGoalWeight.getText().toString().trim(), editGoalWeight);
        if (goal == null) {
            return;
        }

        if (repository.setGoalWeight(userId, goal)) {
            editGoalWeight.setText("");
            refreshGoalDisplay();
            Toast.makeText(this, "Goal weight updated.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Unable to update the goal weight.", Toast.LENGTH_SHORT).show();
        }
    }

    private Double parseWeight(String value, EditText field) {
        Double weight = InputValidator.parseWeight(value);
        if (weight == null) {
            field.setError("Enter a numeric weight between 0 and 1500");
            field.requestFocus();
        }
        return weight;
    }

    private boolean validateDate(String date, EditText field) {
        if (!InputValidator.isValidDate(date)) {
            field.setError("Enter a valid date as MM/DD/YYYY");
            field.requestFocus();
            return false;
        }
        return true;
    }

    /** Rebuilds the table from persistent database records. */
    private void refreshWeightTable() {
        // Row 0 is the header defined in XML. All other rows are database data.
        while (weightTable.getChildCount() > 1) {
            weightTable.removeViewAt(1);
        }

        List<WeightEntry> allEntries = repository.getWeights(userId);
        updateProgressSummary(allEntries);

        List<WeightEntry> entries;
        try {
            // Milestone Four pushes the date-range filter into SQLite so the database
            // can use its (user_id, entry_date_iso) index instead of filtering all rows in memory.
            entries = repository.getWeightsByDateRange(userId, activeFilterFrom, activeFilterTo);
        } catch (IllegalArgumentException exception) {
            Toast.makeText(this, exception.getMessage(), Toast.LENGTH_SHORT).show();
            entries = allEntries;
        }

        if (entries.isEmpty()) {
            TableRow emptyRow = new TableRow(this);
            TextView emptyText = createCell("No saved entries yet.");
            emptyRow.addView(emptyText);
            weightTable.addView(emptyRow);
            return;
        }

        for (WeightEntry entry : entries) {
            TableRow row = new TableRow(this);
            row.setPadding(4, 8, 4, 8);

            row.addView(createCell(entry.getDate()));
            row.addView(createCell(String.format(Locale.US, "%.1f lbs", entry.getWeight())));

            Button editButton = new Button(this);
            editButton.setText("Edit");
            editButton.setTextSize(11);
            editButton.setContentDescription("Edit weight entry for " + entry.getDate());
            editButton.setOnClickListener(view -> showEditDialog(entry));
            row.addView(editButton);

            Button deleteButton = new Button(this);
            deleteButton.setText("Delete");
            deleteButton.setTextSize(11);
            deleteButton.setContentDescription("Delete weight entry for " + entry.getDate());
            deleteButton.setOnClickListener(view -> confirmDelete(entry));
            row.addView(deleteButton);

            weightTable.addView(row);
        }
    }

    private void applyDateFilter() {
        String from = editFilterFrom.getText().toString().trim();
        String to = editFilterTo.getText().toString().trim();
        if (!from.isEmpty() && !InputValidator.isValidDate(from)) {
            editFilterFrom.setError("Enter a valid date as MM/DD/YYYY");
            return;
        }
        if (!to.isEmpty() && !InputValidator.isValidDate(to)) {
            editFilterTo.setError("Enter a valid date as MM/DD/YYYY");
            return;
        }
        try {
            // Validate the range through the repository/database query before activating it.
            repository.getWeightsByDateRange(userId, from, to);
            activeFilterFrom = from;
            activeFilterTo = to;
            refreshWeightTable();
        } catch (IllegalArgumentException exception) {
            editFilterTo.setError("End date must be on or after start date");
        }
    }

    private void clearDateFilter() {
        activeFilterFrom = "";
        activeFilterTo = "";
        editFilterFrom.setText("");
        editFilterTo.setText("");
        refreshWeightTable();
    }

    private void updateProgressSummary(List<WeightEntry> entries) {
        double goal = repository.getGoalWeight(userId);
        WeightAnalytics.ProgressSummary summary = WeightAnalytics.calculateProgress(entries, goal);
        if (summary.isEmpty()) {
            textProgressSummary.setText("Progress: Add at least one weight entry to begin analysis.");
            return;
        }
        String trend = summary.getTrend().name().toLowerCase(Locale.US).replace('_', ' ');
        textProgressSummary.setText(String.format(Locale.US,
                "Progress: %.1f -> %.1f lbs | Net change: %+.1f lbs | %.0f%% toward goal | Remaining: %.1f lbs | Trend: %s",
                summary.getStartingWeight(), summary.getCurrentWeight(), summary.getNetChange(),
                summary.getPercentTowardGoal(), summary.getPoundsRemaining(), trend));
    }

    private TextView createCell(String value) {
        TextView textView = new TextView(this);
        textView.setText(value);
        textView.setPadding(8, 12, 8, 12);
        return textView;
    }

    private void showEditDialog(WeightEntry entry) {
        android.widget.LinearLayout container = new android.widget.LinearLayout(this);
        container.setOrientation(android.widget.LinearLayout.VERTICAL);
        int padding = (int) (20 * getResources().getDisplayMetrics().density);
        container.setPadding(padding, padding, padding, 0);

        EditText dateInput = new EditText(this);
        dateInput.setHint("Date: MM/DD/YYYY");
        dateInput.setText(entry.getDate());
        container.addView(dateInput);

        EditText weightInput = new EditText(this);
        weightInput.setHint("Weight");
        weightInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        weightInput.setText(String.format(Locale.US, "%.1f", entry.getWeight()));
        container.addView(weightInput);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Edit Weight Entry")
                .setView(container)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", null)
                .create();

        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(view -> {
                    String date = dateInput.getText().toString().trim();
                    Double weight = parseWeight(weightInput.getText().toString().trim(), weightInput);
                    if (weight == null) {
                        return;
                    }
                    if (!validateDate(date, dateInput)) {
                        return;
                    }

                    if (repository.updateWeight(entry.getId(), userId, date, weight)) {
                        refreshWeightTable();
                        checkGoalAndSendSms(weight);
                        Toast.makeText(this, "Weight entry updated.", Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                    }
                }));

        dialog.show();
    }

    private void confirmDelete(WeightEntry entry) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Weight Entry")
                .setMessage("Delete the entry for " + entry.getDate() + "?")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (dialog, which) -> {
                    if (repository.deleteWeight(entry.getId(), userId)) {
                        refreshWeightTable();
                        Toast.makeText(this, "Weight entry deleted.", Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }

    private void refreshGoalDisplay() {
        double goal = repository.getGoalWeight(userId);
        textGoalWeight.setText(String.format(Locale.US, "Goal Weight: %.1f lbs", goal));
    }

    private void openNotificationSettings() {
        Intent intent = new Intent(this, SmsPermissionActivity.class);
        intent.putExtra(LoginActivity.EXTRA_USER_ID, userId);
        startActivity(intent);
    }

    private void logOut() {
        Intent intent = new Intent(this, LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }

    /**
     * For this weight-loss scenario, reaching or going below the goal counts
     * as reaching the target. SMS is attempted only when the user opted in,
     * supplied a number, and granted SEND_SMS permission.
     */
    private void checkGoalAndSendSms(double currentWeight) {
        double goalWeight = repository.getGoalWeight(userId);
        if (currentWeight > goalWeight) {
            return;
        }

        if (!repository.isSmsEnabled(userId)) {
            Toast.makeText(this,
                    "Goal reached! SMS notifications are currently off.",
                    Toast.LENGTH_LONG).show();
            return;
        }

        if (checkSelfPermission(Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this,
                    "Goal reached! Grant SMS permission in Notification Settings to receive a text alert.",
                    Toast.LENGTH_LONG).show();
            return;
        }

        String phoneNumber = repository.getPhoneNumber(userId);
        if (phoneNumber.trim().isEmpty()) {
            Toast.makeText(this,
                    "Goal reached! Add a phone number in Notification Settings for SMS alerts.",
                    Toast.LENGTH_LONG).show();
            return;
        }

        String message = String.format(Locale.US,
                "WeightTrack: Congratulations! You reached your goal weight of %.1f lbs.",
                goalWeight);

        try {
            SmsManager.getDefault().sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this,
                    "Goal reached! SMS notification sent.",
                    Toast.LENGTH_LONG).show();
        } catch (Exception exception) {
            Toast.makeText(this,
                    "Goal reached, but the emulator/device could not send the SMS.",
                    Toast.LENGTH_LONG).show();
        }
    }
}

package com.example.modulethreeassignment;

/**
 * Simple model class that represents one saved weight record.
 */
public class WeightEntry {

    private final long id;
    private final String date;
    private final double weight;

    public WeightEntry(long id, String date, double weight) {
        this.id = id;
        this.date = date;
        this.weight = weight;
    }

    public long getId() {
        return id;
    }

    public String getDate() {
        return date;
    }

    public double getWeight() {
        return weight;
    }
}

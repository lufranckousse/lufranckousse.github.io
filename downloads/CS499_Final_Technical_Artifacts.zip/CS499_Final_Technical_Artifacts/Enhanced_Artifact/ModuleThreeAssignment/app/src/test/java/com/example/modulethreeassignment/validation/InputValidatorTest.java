package com.example.modulethreeassignment.validation;

import org.junit.Test;
import static org.junit.Assert.*;

public class InputValidatorTest {
    @Test public void usernameRejectsBlankAndInvalidCharacters() {
        assertNotNull(InputValidator.validateUsername(""));
        assertNotNull(InputValidator.validateUsername("ab"));
        assertNotNull(InputValidator.validateUsername("bad name"));
        assertNull(InputValidator.validateUsername("student_499"));
    }

    @Test public void passwordRequiresEightCharacters() {
        assertNotNull(InputValidator.validatePassword("1234"));
        assertNull(InputValidator.validatePassword("capstone8"));
    }

    @Test public void weightMustBeNumericAndWithinRange() {
        assertNull(InputValidator.parseWeight("abc"));
        assertNull(InputValidator.parseWeight("0"));
        assertNull(InputValidator.parseWeight("1501"));
        assertEquals(225.5, InputValidator.parseWeight("225.5"), 0.001);
    }

    @Test public void dateMustBeRealCalendarDate() {
        assertTrue(InputValidator.isValidDate("09/18/2026"));
        assertFalse(InputValidator.isValidDate("02/30/2026"));
        assertFalse(InputValidator.isValidDate("2026-09-18"));
    }

    @Test public void phoneNumberRequiresTenToFifteenDigits() {
        assertTrue(InputValidator.isValidPhoneNumber("(612) 555-1234"));
        assertTrue(InputValidator.isValidPhoneNumber("+16125551234"));
        assertFalse(InputValidator.isValidPhoneNumber("555"));
    }
}

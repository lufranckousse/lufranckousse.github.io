package com.example.modulethreeassignment.data;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

import org.junit.Test;

public class DatabaseDateCodecTest {
    @Test public void convertsDisplayDateToSortableIsoDate() {
        assertEquals("2026-10-03", DatabaseDateCodec.toStorage("10/03/2026"));
    }

    @Test public void convertsIsoDateBackToDisplayDate() {
        assertEquals("10/03/2026", DatabaseDateCodec.toDisplay("2026-10-03"));
    }

    @Test public void isoDatesSortChronologicallyAsText() {
        String earlier = DatabaseDateCodec.toStorage("09/30/2026");
        String later = DatabaseDateCodec.toStorage("10/03/2026");
        org.junit.Assert.assertTrue(earlier.compareTo(later) < 0);
    }

    @Test public void rejectsInvalidCalendarDate() {
        assertThrows(IllegalArgumentException.class,
                () -> DatabaseDateCodec.toStorage("02/30/2026"));
    }
}

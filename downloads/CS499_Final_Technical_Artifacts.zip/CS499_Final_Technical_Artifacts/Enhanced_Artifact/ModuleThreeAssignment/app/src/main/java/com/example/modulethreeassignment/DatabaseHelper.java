package com.example.modulethreeassignment;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.modulethreeassignment.data.DatabaseDateCodec;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

/** Centralizes SQLite persistence and schema management for the application. */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "weighttrack.db";
    private static final int DATABASE_VERSION = 2;

    private static final String TABLE_USERS = "users";
    private static final String TABLE_WEIGHTS = "weights";
    private static final String TABLE_GOALS = "goals";
    private static final double DEFAULT_GOAL_WEIGHT = 200.0;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_USERS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT NOT NULL UNIQUE CHECK(length(trim(username)) BETWEEN 1 AND 50), " +
                "password_hash TEXT NOT NULL CHECK(length(password_hash) = 64), " +
                "phone TEXT NOT NULL DEFAULT '', " +
                "sms_enabled INTEGER NOT NULL DEFAULT 0 CHECK(sms_enabled IN (0,1)))");

        createWeightsTable(db, TABLE_WEIGHTS);
        createGoalsTable(db, TABLE_GOALS);
        createIndexes(db);
    }

    private void createWeightsTable(SQLiteDatabase db, String tableName) {
        db.execSQL("CREATE TABLE " + tableName + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER NOT NULL, " +
                "entry_date_iso TEXT NOT NULL " +
                "CHECK(length(entry_date_iso) = 10 AND substr(entry_date_iso,5,1) = '-' AND substr(entry_date_iso,8,1) = '-'), " +
                "weight REAL NOT NULL CHECK(weight > 0 AND weight <= 1500), " +
                "UNIQUE(user_id, entry_date_iso), " +
                "FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE)");
    }

    private void createGoalsTable(SQLiteDatabase db, String tableName) {
        db.execSQL("CREATE TABLE " + tableName + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER NOT NULL UNIQUE, " +
                "goal_weight REAL NOT NULL CHECK(goal_weight > 0 AND goal_weight <= 1500), " +
                "FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE)");
    }

    private void createIndexes(SQLiteDatabase db) {
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_weights_user_date " +
                "ON " + TABLE_WEIGHTS + "(user_id, entry_date_iso DESC)");
    }

    /**
     * Version 2 preserves version-1 data while replacing display-formatted dates
     * with ISO dates, adding constraints, and creating a composite query index.
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            migrateToVersion2(db);
        }
    }

    private void migrateToVersion2(SQLiteDatabase db) {
        createWeightsTable(db, "weights_v2");
        db.execSQL("INSERT OR IGNORE INTO weights_v2 (id, user_id, entry_date_iso, weight) " +
                "SELECT id, user_id, " +
                "substr(entry_date, 7, 4) || '-' || substr(entry_date, 1, 2) || '-' || substr(entry_date, 4, 2), " +
                "weight FROM weights WHERE weight > 0 AND weight <= 1500");

        createGoalsTable(db, "goals_v2");
        db.execSQL("INSERT OR IGNORE INTO goals_v2 (id, user_id, goal_weight) " +
                "SELECT id, user_id, goal_weight FROM goals WHERE goal_weight > 0 AND goal_weight <= 1500");

        db.execSQL("DROP TABLE " + TABLE_WEIGHTS);
        db.execSQL("DROP TABLE " + TABLE_GOALS);
        db.execSQL("ALTER TABLE weights_v2 RENAME TO " + TABLE_WEIGHTS);
        db.execSQL("ALTER TABLE goals_v2 RENAME TO " + TABLE_GOALS);
        createIndexes(db);
    }

    public long createUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues userValues = new ContentValues();
            userValues.put("username", username.trim());
            userValues.put("password_hash", hashPassword(password));
            long userId = db.insert(TABLE_USERS, null, userValues);
            if (userId == -1) return -1;

            ContentValues goalValues = new ContentValues();
            goalValues.put("user_id", userId);
            goalValues.put("goal_weight", DEFAULT_GOAL_WEIGHT);
            db.insertOrThrow(TABLE_GOALS, null, goalValues);
            db.setTransactionSuccessful();
            return userId;
        } finally {
            db.endTransaction();
        }
    }

    public long validateUser(String username, String password) {
        try (Cursor cursor = getReadableDatabase().query(TABLE_USERS, new String[]{"id"},
                "username = ? AND password_hash = ?",
                new String[]{username.trim(), hashPassword(password)}, null, null, null)) {
            return cursor.moveToFirst() ? cursor.getLong(cursor.getColumnIndexOrThrow("id")) : -1;
        }
    }

    public boolean usernameExists(String username) {
        try (Cursor cursor = getReadableDatabase().query(TABLE_USERS, new String[]{"id"},
                "username = ?", new String[]{username.trim()}, null, null, null)) {
            return cursor.moveToFirst();
        }
    }

    public long addWeight(long userId, String date, double weight) {
        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("entry_date_iso", DatabaseDateCodec.toStorage(date));
        values.put("weight", weight);
        return getWritableDatabase().insert(TABLE_WEIGHTS, null, values);
    }

    public boolean updateWeight(long entryId, long userId, String date, double weight) {
        ContentValues values = new ContentValues();
        values.put("entry_date_iso", DatabaseDateCodec.toStorage(date));
        values.put("weight", weight);
        return getWritableDatabase().update(TABLE_WEIGHTS, values,
                "id = ? AND user_id = ?", new String[]{String.valueOf(entryId), String.valueOf(userId)}) > 0;
    }

    public boolean deleteWeight(long entryId, long userId) {
        return getWritableDatabase().delete(TABLE_WEIGHTS, "id = ? AND user_id = ?",
                new String[]{String.valueOf(entryId), String.valueOf(userId)}) > 0;
    }

    /** Returns records in database-level chronological order using the indexed ISO date. */
    public List<WeightEntry> getWeights(long userId) {
        return queryWeights(userId, null, null);
    }

    /** Executes an indexed date-range query instead of loading unrelated rows into memory. */
    public List<WeightEntry> getWeightsByDateRange(long userId, String fromDate, String toDate) {
        String fromIso = fromDate == null || fromDate.isEmpty() ? null : DatabaseDateCodec.toStorage(fromDate);
        String toIso = toDate == null || toDate.isEmpty() ? null : DatabaseDateCodec.toStorage(toDate);
        if (fromIso != null && toIso != null && fromIso.compareTo(toIso) > 0) {
            throw new IllegalArgumentException("End date must be on or after start date");
        }
        return queryWeights(userId, fromIso, toIso);
    }

    private List<WeightEntry> queryWeights(long userId, String fromIso, String toIso) {
        List<WeightEntry> entries = new ArrayList<>();
        StringBuilder selection = new StringBuilder("user_id = ?");
        List<String> args = new ArrayList<>();
        args.add(String.valueOf(userId));
        if (fromIso != null) { selection.append(" AND entry_date_iso >= ?"); args.add(fromIso); }
        if (toIso != null) { selection.append(" AND entry_date_iso <= ?"); args.add(toIso); }

        try (Cursor cursor = getReadableDatabase().query(TABLE_WEIGHTS,
                new String[]{"id", "entry_date_iso", "weight"}, selection.toString(),
                args.toArray(new String[0]), null, null, "entry_date_iso DESC, id DESC")) {
            int idIndex = cursor.getColumnIndexOrThrow("id");
            int dateIndex = cursor.getColumnIndexOrThrow("entry_date_iso");
            int weightIndex = cursor.getColumnIndexOrThrow("weight");
            while (cursor.moveToNext()) {
                entries.add(new WeightEntry(cursor.getLong(idIndex),
                        DatabaseDateCodec.toDisplay(cursor.getString(dateIndex)), cursor.getDouble(weightIndex)));
            }
        }
        return entries;
    }

    public double getGoalWeight(long userId) {
        try (Cursor cursor = getReadableDatabase().query(TABLE_GOALS, new String[]{"goal_weight"},
                "user_id = ?", new String[]{String.valueOf(userId)}, null, null, null)) {
            return cursor.moveToFirst() ? cursor.getDouble(cursor.getColumnIndexOrThrow("goal_weight")) : DEFAULT_GOAL_WEIGHT;
        }
    }

    public boolean setGoalWeight(long userId, double goalWeight) {
        ContentValues values = new ContentValues();
        values.put("goal_weight", goalWeight);
        int updated = getWritableDatabase().update(TABLE_GOALS, values,
                "user_id = ?", new String[]{String.valueOf(userId)});
        if (updated > 0) return true;
        values.put("user_id", userId);
        return getWritableDatabase().insert(TABLE_GOALS, null, values) != -1;
    }

    public void setSmsPreferences(long userId, String phoneNumber, boolean enabled) {
        ContentValues values = new ContentValues();
        values.put("phone", phoneNumber.trim());
        values.put("sms_enabled", enabled ? 1 : 0);
        getWritableDatabase().update(TABLE_USERS, values, "id = ?", new String[]{String.valueOf(userId)});
    }

    public String getPhoneNumber(long userId) {
        try (Cursor cursor = getReadableDatabase().query(TABLE_USERS, new String[]{"phone"},
                "id = ?", new String[]{String.valueOf(userId)}, null, null, null)) {
            return cursor.moveToFirst() ? cursor.getString(cursor.getColumnIndexOrThrow("phone")) : "";
        }
    }

    public boolean isSmsEnabled(long userId) {
        try (Cursor cursor = getReadableDatabase().query(TABLE_USERS, new String[]{"sms_enabled"},
                "id = ?", new String[]{String.valueOf(userId)}, null, null, null)) {
            return cursor.moveToFirst() && cursor.getInt(cursor.getColumnIndexOrThrow("sms_enabled")) == 1;
        }
    }

    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder builder = new StringBuilder();
            for (byte value : hash) builder.append(String.format("%02x", value));
            return builder.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 is not available", e);
        }
    }
}

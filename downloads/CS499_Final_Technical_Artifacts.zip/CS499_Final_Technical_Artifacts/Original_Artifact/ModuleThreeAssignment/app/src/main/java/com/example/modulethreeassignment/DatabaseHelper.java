package com.example.modulethreeassignment;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

/**
 * Centralizes all SQLite operations for user accounts, weight entries,
 * goal weights, and SMS settings. Keeping database code in one class makes
 * the Activities easier to read and maintain.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "weighttrack.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_USERS = "users";
    private static final String TABLE_WEIGHTS = "weights";
    private static final String TABLE_GOALS = "goals";

    private static final double DEFAULT_GOAL_WEIGHT = 200.0;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_USERS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT NOT NULL UNIQUE, " +
                "password_hash TEXT NOT NULL, " +
                "phone TEXT DEFAULT '', " +
                "sms_enabled INTEGER NOT NULL DEFAULT 0)");

        db.execSQL("CREATE TABLE " + TABLE_WEIGHTS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER NOT NULL, " +
                "entry_date TEXT NOT NULL, " +
                "weight REAL NOT NULL, " +
                "FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE)");

        db.execSQL("CREATE TABLE " + TABLE_GOALS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER NOT NULL UNIQUE, " +
                "goal_weight REAL NOT NULL, " +
                "FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOALS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    /** Creates a new account and a default goal record. */
    public long createUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues userValues = new ContentValues();
            userValues.put("username", username.trim());
            userValues.put("password_hash", hashPassword(password));
            long userId = db.insert(TABLE_USERS, null, userValues);

            if (userId == -1) {
                return -1;
            }

            ContentValues goalValues = new ContentValues();
            goalValues.put("user_id", userId);
            goalValues.put("goal_weight", DEFAULT_GOAL_WEIGHT);
            db.insertOrThrow(TABLE_GOALS, null, goalValues);

            db.setTransactionSuccessful();
            return userId;
        } finally {
            db.endTransaction();
        }
    }

    /** Returns the user's database ID when credentials are valid, otherwise -1. */
    public long validateUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        String[] columns = {"id"};
        String selection = "username = ? AND password_hash = ?";
        String[] args = {username.trim(), hashPassword(password)};

        try (Cursor cursor = db.query(TABLE_USERS, columns, selection, args,
                null, null, null)) {
            if (cursor.moveToFirst()) {
                return cursor.getLong(cursor.getColumnIndexOrThrow("id"));
            }
        }
        return -1;
    }

    public boolean usernameExists(String username) {
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor cursor = db.query(TABLE_USERS, new String[]{"id"},
                "username = ?", new String[]{username.trim()},
                null, null, null)) {
            return cursor.moveToFirst();
        }
    }

    public long addWeight(long userId, String date, double weight) {
        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("entry_date", date);
        values.put("weight", weight);
        return getWritableDatabase().insert(TABLE_WEIGHTS, null, values);
    }

    public boolean updateWeight(long entryId, long userId, String date, double weight) {
        ContentValues values = new ContentValues();
        values.put("entry_date", date);
        values.put("weight", weight);
        int rows = getWritableDatabase().update(TABLE_WEIGHTS, values,
                "id = ? AND user_id = ?",
                new String[]{String.valueOf(entryId), String.valueOf(userId)});
        return rows > 0;
    }

    public boolean deleteWeight(long entryId, long userId) {
        int rows = getWritableDatabase().delete(TABLE_WEIGHTS,
                "id = ? AND user_id = ?",
                new String[]{String.valueOf(entryId), String.valueOf(userId)});
        return rows > 0;
    }

    public List<WeightEntry> getWeights(long userId) {
        List<WeightEntry> entries = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        try (Cursor cursor = db.query(TABLE_WEIGHTS,
                new String[]{"id", "entry_date", "weight"},
                "user_id = ?", new String[]{String.valueOf(userId)},
                null, null, "id DESC")) {

            int idIndex = cursor.getColumnIndexOrThrow("id");
            int dateIndex = cursor.getColumnIndexOrThrow("entry_date");
            int weightIndex = cursor.getColumnIndexOrThrow("weight");

            while (cursor.moveToNext()) {
                entries.add(new WeightEntry(
                        cursor.getLong(idIndex),
                        cursor.getString(dateIndex),
                        cursor.getDouble(weightIndex)
                ));
            }
        }
        return entries;
    }

    public double getGoalWeight(long userId) {
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor cursor = db.query(TABLE_GOALS, new String[]{"goal_weight"},
                "user_id = ?", new String[]{String.valueOf(userId)},
                null, null, null)) {
            if (cursor.moveToFirst()) {
                return cursor.getDouble(cursor.getColumnIndexOrThrow("goal_weight"));
            }
        }
        return DEFAULT_GOAL_WEIGHT;
    }

    public boolean setGoalWeight(long userId, double goalWeight) {
        ContentValues values = new ContentValues();
        values.put("goal_weight", goalWeight);
        int updated = getWritableDatabase().update(TABLE_GOALS, values,
                "user_id = ?", new String[]{String.valueOf(userId)});

        if (updated > 0) {
            return true;
        }

        values.put("user_id", userId);
        return getWritableDatabase().insert(TABLE_GOALS, null, values) != -1;
    }

    public void setSmsPreferences(long userId, String phoneNumber, boolean enabled) {
        ContentValues values = new ContentValues();
        values.put("phone", phoneNumber.trim());
        values.put("sms_enabled", enabled ? 1 : 0);
        getWritableDatabase().update(TABLE_USERS, values,
                "id = ?", new String[]{String.valueOf(userId)});
    }

    public String getPhoneNumber(long userId) {
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor cursor = db.query(TABLE_USERS, new String[]{"phone"},
                "id = ?", new String[]{String.valueOf(userId)},
                null, null, null)) {
            if (cursor.moveToFirst()) {
                return cursor.getString(cursor.getColumnIndexOrThrow("phone"));
            }
        }
        return "";
    }

    public boolean isSmsEnabled(long userId) {
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor cursor = db.query(TABLE_USERS, new String[]{"sms_enabled"},
                "id = ?", new String[]{String.valueOf(userId)},
                null, null, null)) {
            if (cursor.moveToFirst()) {
                return cursor.getInt(cursor.getColumnIndexOrThrow("sms_enabled")) == 1;
            }
        }
        return false;
    }

    /**
     * Hashes passwords before they are saved. This is appropriate for the
     * class project; a production app would use a stronger password-specific
     * hashing algorithm and additional security controls.
     */
    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder builder = new StringBuilder();
            for (byte value : hash) {
                builder.append(String.format("%02x", value));
            }
            return builder.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 is not available", e);
        }
    }
}

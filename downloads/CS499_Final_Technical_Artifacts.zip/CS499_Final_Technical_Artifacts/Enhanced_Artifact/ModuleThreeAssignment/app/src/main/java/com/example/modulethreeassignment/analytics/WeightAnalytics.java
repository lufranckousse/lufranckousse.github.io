package com.example.modulethreeassignment.analytics;

import com.example.modulethreeassignment.WeightEntry;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Pure-Java algorithms for ordering, filtering, and analyzing weight history.
 * Keeping these operations outside the Activity makes them reusable and unit testable.
 */
public final class WeightAnalytics {
    private static final String DATE_PATTERN = "MM/dd/yyyy";
    private static final double TREND_EPSILON = 0.1;

    private WeightAnalytics() { }

    /** Returns a new list ordered by calendar date. The input list is never modified. */
    public static List<WeightEntry> sortChronologically(List<WeightEntry> entries, boolean newestFirst) {
        List<WeightEntry> sorted = new ArrayList<>(entries == null ? Collections.emptyList() : entries);
        Comparator<WeightEntry> comparator = Comparator.comparingLong(entry -> parseDate(entry.getDate()).getTime());
        if (newestFirst) comparator = comparator.reversed();
        sorted.sort(comparator);
        return sorted;
    }

    /** Inclusive date-range filter. Empty bounds mean that side of the range is unbounded. */
    public static List<WeightEntry> filterByDateRange(List<WeightEntry> entries, String fromDate, String toDate) {
        Date from = isBlank(fromDate) ? null : parseDate(fromDate);
        Date to = isBlank(toDate) ? null : parseDate(toDate);
        if (from != null && to != null && from.after(to)) {
            throw new IllegalArgumentException("Start date must not be after end date");
        }

        List<WeightEntry> filtered = new ArrayList<>();
        if (entries == null) return filtered;
        for (WeightEntry entry : entries) {
            Date date = parseDate(entry.getDate());
            boolean afterStart = from == null || !date.before(from);
            boolean beforeEnd = to == null || !date.after(to);
            if (afterStart && beforeEnd) filtered.add(entry);
        }
        return sortChronologically(filtered, false);
    }

    /** Builds progress metrics from the earliest and latest entries. */
    public static ProgressSummary calculateProgress(List<WeightEntry> entries, double goalWeight) {
        List<WeightEntry> sorted = sortChronologically(entries, false);
        if (sorted.isEmpty()) return ProgressSummary.empty(goalWeight);

        WeightEntry first = sorted.get(0);
        WeightEntry latest = sorted.get(sorted.size() - 1);
        double change = latest.getWeight() - first.getWeight();
        double poundsTowardGoal = first.getWeight() - latest.getWeight();
        double totalNeeded = first.getWeight() - goalWeight;
        double percent = totalNeeded > 0 ? clamp((poundsTowardGoal / totalNeeded) * 100.0, 0.0, 100.0) : 0.0;
        double remaining = Math.max(0.0, latest.getWeight() - goalWeight);
        Trend trend = determineTrend(sorted);

        return new ProgressSummary(false, first.getWeight(), latest.getWeight(), goalWeight,
                change, remaining, percent, trend, sorted.size());
    }

    /**
     * Uses the average change per interval across up to the five most recent chronological entries.
     * Negative average change is DECREASING, positive is INCREASING, and small movement is STABLE.
     */
    public static Trend determineTrend(List<WeightEntry> entries) {
        List<WeightEntry> sorted = sortChronologically(entries, false);
        if (sorted.size() < 2) return Trend.INSUFFICIENT_DATA;
        int start = Math.max(0, sorted.size() - 5);
        double totalChange = 0.0;
        int intervals = 0;
        for (int i = start + 1; i < sorted.size(); i++) {
            totalChange += sorted.get(i).getWeight() - sorted.get(i - 1).getWeight();
            intervals++;
        }
        double averageChange = totalChange / intervals;
        if (averageChange < -TREND_EPSILON) return Trend.DECREASING;
        if (averageChange > TREND_EPSILON) return Trend.INCREASING;
        return Trend.STABLE;
    }

    private static Date parseDate(String value) {
        SimpleDateFormat format = new SimpleDateFormat(DATE_PATTERN, Locale.US);
        format.setLenient(false);
        try {
            return format.parse(value);
        } catch (ParseException exception) {
            throw new IllegalArgumentException("Invalid date: " + value, exception);
        }
    }

    private static boolean isBlank(String value) { return value == null || value.trim().isEmpty(); }
    private static double clamp(double value, double min, double max) { return Math.max(min, Math.min(max, value)); }

    public enum Trend { DECREASING, INCREASING, STABLE, INSUFFICIENT_DATA }

    public static final class ProgressSummary {
        private final boolean empty;
        private final double startingWeight;
        private final double currentWeight;
        private final double goalWeight;
        private final double netChange;
        private final double poundsRemaining;
        private final double percentTowardGoal;
        private final Trend trend;
        private final int entryCount;

        private ProgressSummary(boolean empty, double startingWeight, double currentWeight, double goalWeight,
                                double netChange, double poundsRemaining, double percentTowardGoal,
                                Trend trend, int entryCount) {
            this.empty = empty;
            this.startingWeight = startingWeight;
            this.currentWeight = currentWeight;
            this.goalWeight = goalWeight;
            this.netChange = netChange;
            this.poundsRemaining = poundsRemaining;
            this.percentTowardGoal = percentTowardGoal;
            this.trend = trend;
            this.entryCount = entryCount;
        }

        private static ProgressSummary empty(double goalWeight) {
            return new ProgressSummary(true, 0, 0, goalWeight, 0, 0, 0, Trend.INSUFFICIENT_DATA, 0);
        }

        public boolean isEmpty() { return empty; }
        public double getStartingWeight() { return startingWeight; }
        public double getCurrentWeight() { return currentWeight; }
        public double getGoalWeight() { return goalWeight; }
        public double getNetChange() { return netChange; }
        public double getPoundsRemaining() { return poundsRemaining; }
        public double getPercentTowardGoal() { return percentTowardGoal; }
        public Trend getTrend() { return trend; }
        public int getEntryCount() { return entryCount; }
    }
}

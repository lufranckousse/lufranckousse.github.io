package com.example.modulethreeassignment.data;

import android.content.Context;

import com.example.modulethreeassignment.DatabaseHelper;
import com.example.modulethreeassignment.WeightEntry;

import java.util.List;

/**
 * Data-access boundary used by Activities. UI classes no longer need to know
 * which DatabaseHelper methods implement persistence operations.
 */
public class WeightRepository {
    private final DatabaseHelper databaseHelper;

    public WeightRepository(Context context) {
        databaseHelper = new DatabaseHelper(context.getApplicationContext());
    }

    public long authenticate(String username, String password) { return databaseHelper.validateUser(username, password); }
    public boolean usernameExists(String username) { return databaseHelper.usernameExists(username); }
    public long createUser(String username, String password) { return databaseHelper.createUser(username, password); }
    public long addWeight(long userId, String date, double weight) { return databaseHelper.addWeight(userId, date, weight); }
    public boolean updateWeight(long id, long userId, String date, double weight) { return databaseHelper.updateWeight(id, userId, date, weight); }
    public boolean deleteWeight(long id, long userId) { return databaseHelper.deleteWeight(id, userId); }
    public List<WeightEntry> getWeights(long userId) { return databaseHelper.getWeights(userId); }
    public List<WeightEntry> getWeightsByDateRange(long userId, String from, String to) { return databaseHelper.getWeightsByDateRange(userId, from, to); }
    public double getGoalWeight(long userId) { return databaseHelper.getGoalWeight(userId); }
    public boolean setGoalWeight(long userId, double goal) { return databaseHelper.setGoalWeight(userId, goal); }
    public boolean isSmsEnabled(long userId) { return databaseHelper.isSmsEnabled(userId); }
    public String getPhoneNumber(long userId) { return databaseHelper.getPhoneNumber(userId); }
    public void setSmsPreferences(long userId, String phone, boolean enabled) { databaseHelper.setSmsPreferences(userId, phone, enabled); }
}

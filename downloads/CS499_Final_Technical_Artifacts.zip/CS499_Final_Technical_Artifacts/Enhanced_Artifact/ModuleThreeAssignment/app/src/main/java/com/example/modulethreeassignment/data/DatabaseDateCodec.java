package com.example.modulethreeassignment.data;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;

/**
 * Converts user-facing MM/dd/yyyy dates to ISO yyyy-MM-dd values for SQLite.
 * ISO dates sort correctly as TEXT and make indexed range queries reliable.
 */
public final class DatabaseDateCodec {
    private static final DateTimeFormatter DISPLAY =
            DateTimeFormatter.ofPattern("MM/dd/uuuu").withResolverStyle(ResolverStyle.STRICT);
    private static final DateTimeFormatter STORAGE = DateTimeFormatter.ISO_LOCAL_DATE;

    private DatabaseDateCodec() { }

    public static String toStorage(String displayDate) {
        try {
            return LocalDate.parse(displayDate, DISPLAY).format(STORAGE);
        } catch (DateTimeParseException exception) {
            throw new IllegalArgumentException("Date must be a valid MM/DD/YYYY value", exception);
        }
    }

    public static String toDisplay(String storageDate) {
        try {
            return LocalDate.parse(storageDate, STORAGE).format(DISPLAY);
        } catch (DateTimeParseException exception) {
            throw new IllegalArgumentException("Stored date must use YYYY-MM-DD", exception);
        }
    }
}
